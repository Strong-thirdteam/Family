package bean;

public class score {
	private  String id;
	private  String xuehao;
	private  String name;
	private  String kkxq;
	private  String kcmc;
	private  String score;
	private  String cjbz;
	private  String kcxz;
	private  String kclb;
	private  String xs;
	private  String xf;
	private  String ksxz;
	private  String bcxq;
	private  String bz;
	private  String kcdl;
	private  String tsxlb;
	private  String kssj;	
	//���캯��
	public score(){
		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getXuehao() {
		return xuehao;
	}
	public void setXuehao(String xuehao) {
		this.xuehao = xuehao;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getKkxq() {
		return kkxq;
	}
	public void setKkxq(String kkxq) {
		this.kkxq = kkxq;
	}
	public String getKcmc() {
		return kcmc;
	}
	public void setKcmc(String kcmc) {
		this.kcmc = kcmc;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getCjbz() {
		return cjbz;
	}
	public void setCjbz(String cjbz) {
		this.cjbz = cjbz;
	}
	public String getKcxz() {
		return kcxz;
	}
	public void setKcxz(String kcxz) {
		this.kcxz = kcxz;
	}
	public String getKclb() {
		return kclb;
	}
	public void setKclb(String kclb) {
		this.kclb = kclb;
	}
	public String getXs() {
		return xs;
	}
	public void setXs(String xs) {
		this.xs = xs;
	}
	public String getXf() {
		return xf;
	}
	public void setXf(String xf) {
		this.xf = xf;
	}
	public String getKsxz() {
		return ksxz;
	}
	public void setKsxz(String ksxz) {
		this.ksxz = ksxz;
	}
	public String getBcxq() {
		return bcxq;
	}
	public void setBcxq(String bcxq) {
		this.bcxq = bcxq;
	}
	public String getBz() {
		return bz;
	}
	public void setBz(String bz) {
		this.bz = bz;
	}
	public String getKcdl() {
		return kcdl;
	}
	public void setKcdl(String kcdl) {
		this.kcdl = kcdl;
	}
	public String getTsxlb() {
		return tsxlb;
	}
	public void setTsxlb(String tsxlb) {
		this.tsxlb = tsxlb;
	}
	public String getKssj() {
		return kssj;
	}
	public void setKssj(String kssj) {
		this.kssj = kssj;
	}
	
	
	
	
	
}
